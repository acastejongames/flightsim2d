import { useState } from 'react';
import Menu from './components/Menu';
import GameView from './components/GameView';
import type { SimSettings } from './game/sim';

export default function App() {
  const [settings, setSettings] = useState<SimSettings | null>(null);
  const [run, setRun] = useState(0);

  if (!settings) {
    return (
      <Menu
        onStart={(s) => {
          setSettings(s);
          setRun((r) => r + 1);
        }}
      />
    );
  }
  return <GameView key={run} settings={settings} onExit={() => setSettings(null)} />;
}
