const ROWS: [string, string][] = [
  ['↑ / W   ↓ / S', 'Pitch up / down (elevator)'],
  ['→ / D   ← / A', 'Throttle up / down (afterburner at the top on jets)'],
  ['Z   X', 'Throttle idle / full'],
  ['G', 'Landing gear'],
  ['F', 'Flaps (up → takeoff → landing)'],
  ['B (hold)', 'Wheel brakes / airbrake in flight'],
  ['T', 'Turn around (banked turn in flight, pivot on ground)'],
  ['H', 'Tailhook (carrier aircraft)'],
  ['SPACE', 'Fire the catapult / relaunch after a trap'],
  ['Y', 'Flight assist (auto-trim) on / off'],
  ['K', 'Autothrottle (holds airspeed)'],
  ['Q  E', 'Manual trim (assist off)'],
  ['R', 'Respawn (nearest airfield or catapult)'],
  ['+  −  /  wheel', 'Zoom'],
  ['M', 'Mute'],
  ['P / ESC', 'Pause menu'],
];

export default function Controls({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`grid gap-x-6 gap-y-1.5 ${compact ? 'text-xs' : 'text-sm'} sm:grid-cols-1`}>
      {ROWS.map(([k, d]) => (
        <div key={k} className="flex items-baseline gap-3">
          <span className="w-40 shrink-0 rounded-md bg-white/10 px-2 py-0.5 text-center font-mono text-[11px] font-semibold text-sky-100 ring-1 ring-white/10">
            {k}
          </span>
          <span className="text-slate-300">{d}</span>
        </div>
      ))}
    </div>
  );
}
