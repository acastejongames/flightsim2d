import { useCallback, useEffect, useRef, useState } from 'react';
import { Sim } from '../game/sim';
import type { SimSettings, Input } from '../game/sim';
import { Renderer } from '../game/render';
import type { HudExtra } from '../game/hud';
import { AudioEngine } from '../game/audio';
import Controls from './Controls';

interface Props {
  settings: SimSettings;
  onExit: () => void;
}

type TouchKey = 'up' | 'down' | 'thrUp' | 'thrDown' | 'brake';

export default function GameView({ settings, onExit }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const simRef = useRef<Sim | null>(null);
  const audioRef = useRef<AudioEngine | null>(null);
  const rendRef = useRef<Renderer | null>(null);
  const pausedRef = useRef(false);
  const mutedRef = useRef(false);
  const touchRef = useRef<Record<TouchKey, boolean>>({ up: false, down: false, thrUp: false, thrDown: false, brake: false });
  const [paused, setPausedState] = useState(false);
  const [muted, setMutedState] = useState(false);
  const [coarse, setCoarse] = useState(false);

  const setPaused = useCallback((p: boolean) => {
    pausedRef.current = p;
    setPausedState(p);
    const a = audioRef.current;
    if (a) {
      if (p) a.suspend();
      else a.resume();
    }
  }, []);

  const setMuted = useCallback((m: boolean) => {
    mutedRef.current = m;
    setMutedState(m);
    audioRef.current?.setMuted(m);
  }, []);

  useEffect(() => {
    setCoarse(window.matchMedia('(pointer: coarse)').matches);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const sim = new Sim(settings);
    const rend = new Renderer(canvas, settings.tod);
    const audio = new AudioEngine();
    audio.init(settings.spec.kind);
    simRef.current = sim;
    rendRef.current = rend;
    audioRef.current = audio;

    const resize = () => rend.resize(window.innerWidth, window.innerHeight, Math.min(window.devicePixelRatio || 1, 2));
    resize();
    window.addEventListener('resize', resize);

    const keys = new Set<string>();
    const handled = new Set([
      'ArrowUp',
      'ArrowDown',
      'ArrowLeft',
      'ArrowRight',
      'Space',
      'KeyW',
      'KeyA',
      'KeyS',
      'KeyD',
    ]);

    const onKeyDown = (e: KeyboardEvent) => {
      if (handled.has(e.code)) e.preventDefault();
      audio.resume();
      if (e.repeat) {
        keys.add(e.code);
        return;
      }
      keys.add(e.code);
      switch (e.code) {
        case 'KeyG':
          sim.toggleGear();
          break;
        case 'KeyF':
          sim.cycleFlaps();
          break;
        case 'KeyH':
          sim.toggleHook();
          break;
        case 'KeyT':
          sim.startTurn();
          break;
        case 'Space':
          sim.launch();
          break;
        case 'KeyY':
          sim.toggleAssist();
          break;
        case 'KeyK':
          sim.toggleAutoThrottle();
          break;
        case 'KeyR':
          sim.respawn();
          break;
        case 'KeyZ':
          sim.autoThr = false;
          sim.throttle = 0;
          break;
        case 'KeyX':
          sim.autoThr = false;
          sim.throttle = 1;
          break;
        case 'KeyQ':
          sim.trim(-1);
          break;
        case 'KeyE':
          sim.trim(1);
          break;
        case 'KeyM':
          setMuted(!mutedRef.current);
          break;
        case 'Equal':
        case 'NumpadAdd':
          rend.userZoom = Math.min(2.4, rend.userZoom * 1.15);
          break;
        case 'Minus':
        case 'NumpadSubtract':
          rend.userZoom = Math.max(0.5, rend.userZoom / 1.15);
          break;
        case 'Escape':
        case 'KeyP':
          setPaused(!pausedRef.current);
          break;
      }
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keys.delete(e.code);
    };
    const onWheel = (e: WheelEvent) => {
      rend.userZoom = Math.min(2.4, Math.max(0.5, rend.userZoom * Math.exp(-e.deltaY * 0.001)));
    };
    const onBlur = () => {
      keys.clear();
      setPaused(true);
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('wheel', onWheel, { passive: true });
    window.addEventListener('blur', onBlur);

    const extra: HudExtra = { paused: false, fps: 60, muted: false, showHelp: false };
    let last = performance.now();
    let raf = 0;
    const input: Input = { pitch: 0, thr: 0, brake: false };

    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      const t = touchRef.current;
      const up = keys.has('ArrowUp') || keys.has('KeyW') || t.up;
      const down = keys.has('ArrowDown') || keys.has('KeyS') || t.down;
      const tu = keys.has('ArrowRight') || keys.has('KeyD') || t.thrUp;
      const td = keys.has('ArrowLeft') || keys.has('KeyA') || t.thrDown;
      input.pitch = (up ? 1 : 0) - (down ? 1 : 0);
      input.thr = (tu ? 1 : 0) - (td ? 1 : 0);
      input.brake = keys.has('KeyB') || t.brake;
      if (!pausedRef.current) {
        sim.update(dt, input);
        audio.update(sim);
      }
      extra.paused = pausedRef.current;
      extra.muted = mutedRef.current;
      rend.frame(sim, pausedRef.current ? 0.0001 : dt, extra);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('wheel', onWheel);
      window.removeEventListener('blur', onBlur);
      audio.dispose();
    };
  }, [settings, setPaused, setMuted]);

  const touchBtn = (key: TouchKey, label: string, cls = '') => (
    <button
      className={`select-none touch-none rounded-2xl bg-white/15 px-4 py-3 text-lg font-bold text-white ring-1 ring-white/25 backdrop-blur active:bg-white/35 ${cls}`}
      onPointerDown={(e) => {
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        touchRef.current[key] = true;
      }}
      onPointerUp={() => (touchRef.current[key] = false)}
      onPointerCancel={() => (touchRef.current[key] = false)}
    >
      {label}
    </button>
  );
  const actBtn = (label: string, fn: (s: Sim) => void) => (
    <button
      className="select-none touch-none rounded-xl bg-white/15 px-3 py-2 text-xs font-bold text-white ring-1 ring-white/25 backdrop-blur active:bg-white/35"
      onPointerDown={() => simRef.current && fn(simRef.current)}
    >
      {label}
    </button>
  );

  return (
    <div className="fixed inset-0 overflow-hidden bg-black">
      <canvas ref={canvasRef} className="block h-full w-full" />

      {/* top-center button cluster */}
      <div className="pointer-events-none absolute left-1/2 top-3 z-10 flex -translate-x-1/2 gap-2">
        <button
          onClick={() => setPaused(!paused)}
          className="pointer-events-auto rounded-full bg-slate-900/70 px-3.5 py-1.5 text-xs font-semibold text-slate-100 ring-1 ring-white/15 backdrop-blur transition hover:bg-slate-800/80"
        >
          {paused ? '▶ Resume' : '❚❚ Pause'}
        </button>
        <button
          onClick={() => setMuted(!muted)}
          className="pointer-events-auto rounded-full bg-slate-900/70 px-3.5 py-1.5 text-xs font-semibold text-slate-100 ring-1 ring-white/15 backdrop-blur transition hover:bg-slate-800/80"
        >
          {muted ? '🔇 Muted' : '🔊 Sound'}
        </button>
        <button
          onClick={onExit}
          className="pointer-events-auto rounded-full bg-slate-900/70 px-3.5 py-1.5 text-xs font-semibold text-slate-100 ring-1 ring-white/15 backdrop-blur transition hover:bg-slate-800/80"
        >
          ☰ Menu
        </button>
      </div>

      {coarse && !paused && (
        <>
          <div className="absolute bottom-40 left-3 z-10 flex flex-col gap-3">
            {touchBtn('up', '▲ Pull')}
            {touchBtn('down', '▼ Push')}
          </div>
          <div className="absolute bottom-40 right-3 z-10 flex flex-col gap-3">
            {touchBtn('thrUp', 'Thr +')}
            {touchBtn('thrDown', 'Thr −')}
          </div>
          <div className="absolute bottom-40 left-1/2 z-10 flex -translate-x-1/2 flex-wrap justify-center gap-2">
            {actBtn('GEAR', (s) => s.toggleGear())}
            {actBtn('FLAPS', (s) => s.cycleFlaps())}
            {actBtn('HOOK', (s) => s.toggleHook())}
            {actBtn('TURN', (s) => s.startTurn())}
            {actBtn('LAUNCH', (s) => s.launch())}
            {actBtn('RESET', (s) => s.respawn())}
            {touchBtn('brake', 'BRK', '!px-3 !py-2 !text-xs !rounded-xl')}
          </div>
        </>
      )}

      {paused && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-sm">
          <div className="max-h-full w-full max-w-2xl overflow-y-auto rounded-3xl bg-slate-900/90 p-6 shadow-2xl ring-1 ring-white/10">
            <div className="mb-5 flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight text-white">Paused</h2>
                <p className="text-sm text-slate-400">
                  {settings.spec.name} · {settings.mode === 'carrier' ? 'Carrier Ops' : 'Open World'}
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    simRef.current?.respawn();
                    setPaused(false);
                  }}
                  className="rounded-xl bg-white/10 px-4 py-2 text-sm font-semibold text-white ring-1 ring-white/15 transition hover:bg-white/20"
                >
                  Respawn
                </button>
                <button
                  onClick={onExit}
                  className="rounded-xl bg-white/10 px-4 py-2 text-sm font-semibold text-white ring-1 ring-white/15 transition hover:bg-white/20"
                >
                  Main menu
                </button>
                <button
                  onClick={() => setPaused(false)}
                  className="rounded-xl bg-sky-500 px-5 py-2 text-sm font-bold text-slate-950 shadow-lg shadow-sky-500/30 transition hover:bg-sky-400"
                >
                  Resume
                </button>
              </div>
            </div>
            <Controls compact />
          </div>
        </div>
      )}
    </div>
  );
}
