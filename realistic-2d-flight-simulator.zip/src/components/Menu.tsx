import { useState } from 'react';
import { AIRCRAFT } from '../game/aircraft';
import type { AircraftId, AircraftSpec } from '../game/aircraft';
import type { SimSettings } from '../game/sim';
import type { TimeOfDay, WorldMode } from '../game/world';
import { TODS } from '../game/world';
import AircraftPreview from './AircraftPreview';
import Controls from './Controls';

function Bar({ label, v }: { label: string; v: number }) {
  return (
    <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-slate-400">
      <span className="w-14">{label}</span>
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
        <div className="h-full rounded-full bg-gradient-to-r from-sky-400 to-cyan-300" style={{ width: `${v * 100}%` }} />
      </div>
    </div>
  );
}

function Seg<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { id: T; label: string; icon?: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="inline-flex flex-wrap gap-1 rounded-2xl bg-black/30 p-1 ring-1 ring-white/10">
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          className={`rounded-xl px-3.5 py-2 text-sm font-semibold transition ${
            value === o.id ? 'bg-sky-500 text-slate-950 shadow-lg shadow-sky-500/25' : 'text-slate-300 hover:bg-white/10'
          }`}
        >
          {o.icon && <span className="mr-1.5">{o.icon}</span>}
          {o.label}
        </button>
      ))}
    </div>
  );
}

export default function Menu({ onStart }: { onStart: (s: SimSettings) => void }) {
  const [mode, setMode] = useState<WorldMode>('open');
  const [acId, setAcId] = useState<AircraftId>('sparrow');
  const [tod, setTod] = useState<TimeOfDay>('day');
  const [startAir, setStartAir] = useState(false);
  const [showCtl, setShowCtl] = useState(false);

  const spec: AircraftSpec = AIRCRAFT.find((a) => a.id === acId) ?? AIRCRAFT[0];

  const pickMode = (m: WorldMode) => {
    setMode(m);
    if (m === 'carrier' && !spec.carrier) setAcId('hornet');
  };

  return (
    <div className="relative min-h-screen w-full overflow-y-auto bg-slate-950 text-white">
      <div
        className="pointer-events-none fixed inset-0 bg-cover bg-center opacity-60"
        style={{ backgroundImage: "url('images/hero.jpg')" }}
      />
      <div className="pointer-events-none fixed inset-0 bg-gradient-to-b from-slate-950/70 via-slate-950/60 to-slate-950" />

      <div className="relative mx-auto flex min-h-screen max-w-6xl flex-col px-5 py-8 sm:px-8">
        {/* header */}
        <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-sky-400/15 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em] text-sky-200 ring-1 ring-sky-300/25">
              ✈ Side-scrolling flight sim
            </div>
            <h1 className="bg-gradient-to-r from-white via-sky-100 to-sky-300 bg-clip-text text-5xl font-black tracking-tight text-transparent sm:text-6xl">
              SKYBOUND
            </h1>
            <p className="mt-2 max-w-xl text-slate-300">
              Real lift, drag, stall and thrust physics. Fly an endless procedural world, or earn your wings on the deck of a
              moving carrier — catapult launches, tailhook traps and the meatball.
            </p>
          </div>
          <button
            onClick={() => setShowCtl((s) => !s)}
            className="rounded-xl bg-white/10 px-4 py-2 text-sm font-semibold ring-1 ring-white/15 transition hover:bg-white/20"
          >
            {showCtl ? 'Hide controls' : '⌨ Controls'}
          </button>
        </header>

        {showCtl && (
          <div className="mb-8 rounded-3xl bg-slate-900/80 p-6 ring-1 ring-white/10 backdrop-blur">
            <Controls />
          </div>
        )}

        {/* mode */}
        <section className="mb-8">
          <h2 className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-slate-400">1 · Game mode</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            {(
              [
                {
                  id: 'open' as WorldMode,
                  title: 'Open World',
                  icon: '🏔',
                  text: 'An endless procedural world of coastlines, mountain ranges, villages and airfields every ~16 km. Take off, explore, navigate and land anywhere.',
                },
                {
                  id: 'carrier' as WorldMode,
                  title: 'Carrier Ops',
                  icon: '⚓',
                  text: 'A 300 m carrier steaming at 30 knots. Launch off the catapult, then trap the 3-wire with your hook — guided by the optical landing system.',
                },
              ]
            ).map((m) => (
              <button
                key={m.id}
                onClick={() => pickMode(m.id)}
                className={`group rounded-3xl p-5 text-left ring-1 backdrop-blur transition ${
                  mode === m.id ? 'bg-sky-500/20 ring-sky-300/60 shadow-xl shadow-sky-500/10' : 'bg-slate-900/60 ring-white/10 hover:bg-slate-900/80'
                }`}
              >
                <div className="mb-1 flex items-center gap-3">
                  <span className="text-2xl">{m.icon}</span>
                  <span className="text-xl font-bold">{m.title}</span>
                  {mode === m.id && <span className="ml-auto rounded-full bg-sky-400 px-2 py-0.5 text-[10px] font-bold text-slate-950">SELECTED</span>}
                </div>
                <p className="text-sm text-slate-300">{m.text}</p>
              </button>
            ))}
          </div>
        </section>

        {/* aircraft */}
        <section className="mb-8">
          <h2 className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-slate-400">2 · Aircraft</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {AIRCRAFT.map((a) => {
              const disabled = mode === 'carrier' && !a.carrier;
              const sel = a.id === acId && !disabled;
              return (
                <button
                  key={a.id}
                  disabled={disabled}
                  onClick={() => setAcId(a.id)}
                  className={`relative overflow-hidden rounded-3xl p-4 text-left ring-1 backdrop-blur transition ${
                    sel ? 'bg-sky-500/20 ring-sky-300/60 shadow-xl shadow-sky-500/10' : 'bg-slate-900/60 ring-white/10 hover:bg-slate-900/80'
                  } ${disabled ? 'cursor-not-allowed opacity-40' : ''}`}
                >
                  <div className="flex justify-center rounded-2xl bg-gradient-to-b from-sky-400/25 to-sky-200/5 py-2">
                    <AircraftPreview spec={a} />
                  </div>
                  <div className="mt-3 flex items-baseline justify-between">
                    <span className="text-lg font-bold">{a.name}</span>
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-sky-300">{a.role}</span>
                  </div>
                  <p className="mb-3 mt-1 min-h-[3.2rem] text-xs leading-relaxed text-slate-300">{a.desc}</p>
                  <div className="space-y-1.5">
                    <Bar label="Speed" v={a.stats.speed} />
                    <Bar label="Climb" v={a.stats.climb} />
                    <Bar label="Agility" v={a.stats.agility} />
                    <Bar label="Range" v={a.stats.range} />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-1.5 text-[10px] font-semibold">
                    <span className="rounded-md bg-white/10 px-2 py-0.5 text-slate-200">Vs {Math.round(a.vs * 1.944)} kt</span>
                    <span className="rounded-md bg-white/10 px-2 py-0.5 text-slate-200">{a.gmax} g</span>
                    <span className="rounded-md bg-white/10 px-2 py-0.5 text-slate-200">{a.kind === 'jet' ? 'Afterburner' : 'Piston'}</span>
                    {a.carrier ? (
                      <span className="rounded-md bg-amber-400/20 px-2 py-0.5 text-amber-200">Tailhook</span>
                    ) : (
                      <span className="rounded-md bg-white/5 px-2 py-0.5 text-slate-400">No carrier ops</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* options */}
        <section className="mb-8 grid gap-6 sm:grid-cols-2">
          <div>
            <h2 className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-slate-400">3 · Time of day</h2>
            <Seg<TimeOfDay>
              value={tod}
              onChange={setTod}
              options={[
                { id: 'dawn', label: TODS.dawn.label, icon: '🌅' },
                { id: 'day', label: TODS.day.label, icon: '☀️' },
                { id: 'dusk', label: TODS.dusk.label, icon: '🌇' },
                { id: 'night', label: TODS.night.label, icon: '🌙' },
              ]}
            />
          </div>
          <div>
            <h2 className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-slate-400">4 · Start</h2>
            <Seg<'ground' | 'air'>
              value={startAir ? 'air' : 'ground'}
              onChange={(v) => setStartAir(v === 'air')}
              options={
                mode === 'carrier'
                  ? [
                      { id: 'ground', label: 'On the catapult', icon: '🚀' },
                      { id: 'air', label: 'On final approach', icon: '🎯' },
                    ]
                  : [
                      { id: 'ground', label: 'On the runway', icon: '🛫' },
                      { id: 'air', label: 'In the air', icon: '☁️' },
                    ]
              }
            />
          </div>
        </section>

        <div className="mt-auto flex flex-wrap items-center justify-between gap-4 pb-4">
          <p className="max-w-lg text-xs text-slate-400">
            Tip: flight assist (auto-trim) is on by default — toggle it with <b className="text-slate-200">Y</b> for a purer
            experience. On approach, hold the meatball centred, keep the AoA in the green and aim for the 3-wire.
          </p>
          <button
            onClick={() =>
              onStart({
                mode,
                spec: mode === 'carrier' && !spec.carrier ? AIRCRAFT[2] : spec,
                tod,
                startAir,
              })
            }
            className="group inline-flex items-center gap-3 rounded-2xl bg-gradient-to-r from-sky-400 to-cyan-300 px-9 py-4 text-lg font-black tracking-wide text-slate-950 shadow-2xl shadow-sky-500/30 transition hover:scale-[1.03] active:scale-[0.99]"
          >
            START ENGINES
            <span className="transition group-hover:translate-x-1">➜</span>
          </button>
        </div>
      </div>
    </div>
  );
}
