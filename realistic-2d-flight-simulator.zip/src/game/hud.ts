import { clamp } from './noise';
import type { Sim } from './sim';
import { airportsNear } from './world';

export interface HudExtra {
  paused: boolean;
  fps: number;
  muted: boolean;
  showHelp: boolean;
}

const MONO = 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';
const SANS = 'ui-sans-serif, system-ui, -apple-system, Segoe UI, sans-serif';

function rr(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function panel(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number): void {
  rr(ctx, x, y, w, h, 14);
  ctx.fillStyle = 'rgba(8,14,26,0.64)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.13)';
  ctx.lineWidth = 1;
  ctx.stroke();
}

function label(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, align: CanvasTextAlign = 'left'): void {
  ctx.font = `600 10px ${SANS}`;
  ctx.fillStyle = 'rgba(160,185,215,0.8)';
  ctx.textAlign = align;
  ctx.fillText(text, x, y);
}

function value(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, size = 28, color = '#f1f6ff', align: CanvasTextAlign = 'left'): void {
  ctx.font = `700 ${size}px ${MONO}`;
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.fillText(text, x, y);
}

function chip(ctx: CanvasRenderingContext2D, text: string, x: number, y: number, w: number, on: boolean, color: string): void {
  rr(ctx, x, y, w, 20, 6);
  ctx.fillStyle = on ? color : 'rgba(255,255,255,0.06)';
  ctx.fill();
  ctx.font = `700 10px ${SANS}`;
  ctx.fillStyle = on ? '#06101c' : 'rgba(190,205,225,0.55)';
  ctx.textAlign = 'center';
  ctx.fillText(text, x + w / 2, y + 14);
}

function attitude(ctx: CanvasRenderingContext2D, cx: number, cy: number, r: number, sim: Sim): void {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.clip();
  let pitch = sim.p;
  let roll = 0;
  if (sim.turning && sim.turnKind === 'air') roll = -1.0 * Math.sin(Math.PI * sim.turnT) * sim.hdg;
  if (Math.cos(pitch) < 0) {
    roll += Math.PI;
    pitch = Math.sign(pitch) * (Math.PI - Math.abs(pitch));
  }
  const k = r / 0.75;
  ctx.translate(cx, cy);
  ctx.rotate(roll);
  ctx.translate(0, pitch * k);
  const sky = ctx.createLinearGradient(0, -r * 3, 0, 0);
  sky.addColorStop(0, '#1e5fb0');
  sky.addColorStop(1, '#6fb4ee');
  ctx.fillStyle = sky;
  ctx.fillRect(-r * 3, -r * 4, r * 6, r * 4);
  const gr = ctx.createLinearGradient(0, 0, 0, r * 3);
  gr.addColorStop(0, '#8a6a42');
  gr.addColorStop(1, '#3e2c18');
  ctx.fillStyle = gr;
  ctx.fillRect(-r * 3, 0, r * 6, r * 4);
  ctx.strokeStyle = 'rgba(255,255,255,0.95)';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(-r * 2, 0);
  ctx.lineTo(r * 2, 0);
  ctx.stroke();
  ctx.lineWidth = 1;
  ctx.font = `600 8px ${MONO}`;
  ctx.fillStyle = 'rgba(255,255,255,0.9)';
  ctx.textAlign = 'center';
  for (let d = -40; d <= 40; d += 10) {
    if (d === 0) continue;
    const y = -(d * Math.PI) / 180 * k;
    const w = d % 20 === 0 ? 16 : 9;
    ctx.beginPath();
    ctx.moveTo(-w, y);
    ctx.lineTo(w, y);
    ctx.stroke();
    if (d % 20 === 0) {
      ctx.fillText(String(Math.abs(d)), -w - 8, y + 3);
      ctx.fillText(String(Math.abs(d)), w + 8, y + 3);
    }
  }
  ctx.restore();
  // velocity vector
  ctx.save();
  ctx.translate(cx, cy);
  const a = clamp(sim.aoa, -0.6, 0.6);
  const vy = a * k;
  ctx.strokeStyle = '#7dff9a';
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.arc(0, vy, 4.5, 0, Math.PI * 2);
  ctx.moveTo(-11, vy);
  ctx.lineTo(-4.5, vy);
  ctx.moveTo(4.5, vy);
  ctx.lineTo(11, vy);
  ctx.moveTo(0, vy - 4.5);
  ctx.lineTo(0, vy - 9);
  ctx.stroke();
  // fixed aircraft symbol
  ctx.strokeStyle = '#ffd24a';
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.moveTo(-r * 0.62, 0);
  ctx.lineTo(-r * 0.22, 0);
  ctx.lineTo(-r * 0.12, 7);
  ctx.moveTo(r * 0.62, 0);
  ctx.lineTo(r * 0.22, 0);
  ctx.lineTo(r * 0.12, 7);
  ctx.stroke();
  ctx.fillStyle = '#ffd24a';
  ctx.fillRect(-1.5, -1.5, 3, 3);
  ctx.restore();
  ctx.strokeStyle = 'rgba(255,255,255,0.35)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();
}

function ols(ctx: CanvasRenderingContext2D, W: number, H: number, sim: Sim): void {
  const err = sim.olsError();
  if (err === null || !sim.alive) return;
  const x = W - 74;
  const y = H / 2 - 110;
  const h = 220;
  panel(ctx, x - 34, y - 26, 68, h + 52);
  label(ctx, 'MEATBALL', x, y - 10, 'center');
  const cy = y + h / 2;
  ctx.fillStyle = 'rgba(255,255,255,0.08)';
  rr(ctx, x - 5, y, 10, h, 5);
  ctx.fill();
  // datum lights
  for (const sx of [-24, -17, 17, 24]) {
    ctx.save();
    ctx.shadowColor = '#35e07a';
    ctx.shadowBlur = 8;
    ctx.fillStyle = '#35e07a';
    ctx.beginPath();
    ctx.arc(x + sx, cy, 3.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  const by = clamp(cy - (err / 1.3) * (h / 2 - 12), y + 8, y + h - 8);
  const low = err < -0.5;
  const color = Math.abs(err) > 1.0 ? '#ff4040' : low ? '#ff9f2e' : '#ffc233';
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = 14;
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, by, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  const txt = err > 0.5 ? 'HIGH' : err < -0.5 ? 'LOW' : 'ON GLIDE';
  label(ctx, txt, x, y + h + 18, 'center');
  const tdX = (sim.carrier ? sim.carrier.x : 0) + 82;
  const rng = Math.max(0, (tdX - sim.x) / 1000);
  label(ctx, `${rng.toFixed(1)} km`, x, y + h + 32 - 2, 'center');
}

export function drawHUD(ctx: CanvasRenderingContext2D, W: number, H: number, sim: Sim, extra: HudExtra): void {
  const s = sim.spec;
  const kt = sim.ias * 1.944;
  const ft = sim.y * 3.281;
  const aglFt = Math.max(0, sim.agl) * 3.281;
  const fpm = sim.vy * 196.85;

  // ---------------- messages
  let my = 70;
  for (const m of sim.msgs.slice(-3)) {
    const fade = clamp(Math.min(m.t / 0.2, (m.dur - m.t) / 0.6), 0, 1);
    const col = m.kind === 'good' ? '#7dffa6' : m.kind === 'warn' ? '#ffc65a' : m.kind === 'bad' ? '#ff6b5e' : '#e8f1ff';
    ctx.globalAlpha = fade;
    ctx.textAlign = 'center';
    ctx.font = `800 26px ${SANS}`;
    ctx.fillStyle = 'rgba(0,0,0,0.5)';
    ctx.fillText(m.text, W / 2 + 1.5, my + 1.5);
    ctx.fillStyle = col;
    ctx.fillText(m.text, W / 2, my);
    if (m.sub) {
      ctx.font = `500 14px ${SANS}`;
      ctx.fillStyle = 'rgba(0,0,0,0.5)';
      ctx.fillText(m.sub, W / 2 + 1, my + 22);
      ctx.fillStyle = 'rgba(235,242,255,0.92)';
      ctx.fillText(m.sub, W / 2, my + 21);
      my += 28;
    }
    my += 36;
    ctx.globalAlpha = 1;
  }

  // ---------------- warnings
  const warns: string[] = [];
  if (sim.alive) {
    if (sim.pullUp) warns.push('PULL UP');
    if (sim.stallWarn) warns.push('STALL');
    if (sim.overspeed) warns.push('OVERSPEED');
    if (sim.engineOut) warns.push('ENGINE OUT');
    if (!s.fixedGear && !sim.grounded && sim.gearCmd < 0.5 && sim.agl < 120 && sim.ias < 1.5 * s.vs && sim.vy < 0) warns.push('GEAR');
    if (sim.g > 7) warns.push('G-LIMIT');
  }
  if (warns.length) {
    const flash = Math.floor(sim.time * 4) % 2 === 0;
    ctx.textAlign = 'center';
    ctx.font = `900 30px ${SANS}`;
    warns.forEach((w, i) => {
      ctx.fillStyle = flash ? '#ff3b30' : '#ffb3ad';
      ctx.fillText(w, W / 2, H * 0.3 + i * 36);
    });
  }

  // ---------------- top-left info
  panel(ctx, 14, 14, 250, 62);
  ctx.textAlign = 'left';
  ctx.font = `800 13px ${SANS}`;
  ctx.fillStyle = '#e8f1ff';
  ctx.fillText(`${s.name.toUpperCase()}`, 28, 36);
  ctx.font = `500 11px ${SANS}`;
  ctx.fillStyle = 'rgba(160,185,215,0.9)';
  ctx.fillText(`${sim.mode === 'carrier' ? 'CARRIER OPS' : 'OPEN WORLD'}  ·  Score ${sim.score}`, 28, 53);
  const mins = Math.floor(sim.flightTime / 60);
  const secs = Math.floor(sim.flightTime % 60);
  ctx.fillText(`${mins}:${secs.toString().padStart(2, '0')}  ·  ${(sim.distance / 1000).toFixed(1)} km  ·  ${sim.mode === 'carrier' ? `Traps ${sim.traps}` : `Landings ${sim.landings}`}`, 28, 68);

  // ---------------- nav panel (top right)
  {
    const rows: { name: string; dx: number; carrier: boolean }[] = [];
    if (sim.mode === 'open') {
      for (const ap of airportsNear(sim.x, 2)) rows.push({ name: ap.name, dx: ap.x - sim.x, carrier: false });
    } else if (sim.carrier) {
      rows.push({ name: 'USS Aurora (CV)', dx: sim.carrier.x + 150 - sim.x, carrier: true });
    }
    rows.sort((a, b) => Math.abs(a.dx) - Math.abs(b.dx));
    const list = rows.slice(0, 3);
    const w = 230;
    const x = W - w - 14;
    panel(ctx, x, 14, w, 34 + list.length * 22);
    label(ctx, sim.mode === 'carrier' ? 'CARRIER' : 'NEAREST AIRFIELDS', x + 14, 32);
    list.forEach((r, i) => {
      const y = 54 + i * 22;
      ctx.textAlign = 'left';
      ctx.font = `600 12px ${SANS}`;
      ctx.fillStyle = '#e8f1ff';
      ctx.fillText(r.name, x + 14, y);
      ctx.textAlign = 'right';
      ctx.font = `700 12px ${MONO}`;
      ctx.fillStyle = r.carrier ? '#ffd24a' : '#8fd0ff';
      const km = Math.abs(r.dx) / 1000;
      ctx.fillText(`${r.dx < 0 ? '◀' : '▶'} ${km < 10 ? km.toFixed(1) : Math.round(km)} km`, x + w - 14, y);
    });
  }

  // ---------------- flight instrument panel
  const pw = Math.min(W - 28 - 260, 600);
  const px = 14;
  const py = H - 146;
  if (pw > 360) {
    panel(ctx, px, py, pw, 132);
    attitude(ctx, px + 74, py + 66, 52, sim);
    const c1 = px + 148;
    label(ctx, 'AIRSPEED  KT', c1, py + 26);
    value(ctx, String(Math.round(kt)).padStart(3, ' '), c1, py + 58, 32, sim.stallWarn ? '#ff6b5e' : sim.overspeed ? '#ff6b5e' : '#f1f6ff');
    ctx.font = `600 11px ${MONO}`;
    ctx.fillStyle = 'rgba(160,185,215,0.9)';
    ctx.textAlign = 'left';
    ctx.fillText(`M ${sim.mach.toFixed(2)}`, c1, py + 78);
    ctx.fillText(`GS ${Math.round(Math.abs(sim.worldVx) * 1.944)} kt`, c1 + 62, py + 78);
    if (sim.autoThr) {
      ctx.fillStyle = '#7dffa6';
      ctx.fillText(`A/T SET ${Math.round(sim.atTarget * 1.944)}`, c1, py + 98);
    }
    // speed bar relative to stall
    const barW = 110;
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    rr(ctx, c1, py + 108, barW, 6, 3);
    ctx.fill();
    const vsf = clamp(sim.ias / (s.vne * 1.1), 0, 1);
    ctx.fillStyle = '#4aa8ff';
    rr(ctx, c1, py + 108, Math.max(4, barW * vsf), 6, 3);
    ctx.fill();
    ctx.fillStyle = '#ff6b5e';
    ctx.fillRect(c1 + barW * clamp(s.vs / (s.vne * 1.1), 0, 1), py + 105, 2, 12);
    ctx.fillStyle = '#ffd24a';
    ctx.fillRect(c1 + barW * clamp(s.vApproach / (s.vne * 1.1), 0, 1), py + 105, 2, 12);

    const c2 = c1 + 150;
    label(ctx, 'ALTITUDE  FT', c2, py + 26);
    value(ctx, Math.round(ft).toLocaleString('en-US'), c2, py + 58, 30);
    ctx.font = `600 11px ${MONO}`;
    ctx.textAlign = 'left';
    ctx.fillStyle = fpm < -1800 ? '#ff6b5e' : fpm < 0 ? '#ffc65a' : '#7dffa6';
    ctx.fillText(`V/S ${fpm >= 0 ? '+' : ''}${Math.round(fpm / 10) * 10} fpm`, c2, py + 78);
    ctx.fillStyle = 'rgba(160,185,215,0.9)';
    ctx.fillText(sim.grounded ? 'ON GROUND' : `AGL ${aglFt < 3000 ? Math.round(aglFt) : Math.round(aglFt / 10) * 10} ft`, c2, py + 98);
    ctx.fillText(`HDG ${sim.hdg > 0 ? 'EAST' : 'WEST'}${sim.turning ? ' (turning)' : ''}`, c2, py + 116);

    const c3 = c2 + 138;
    label(ctx, 'LOAD', c3, py + 26);
    const gc = sim.g > 6 ? '#ff6b5e' : sim.g > 4 ? '#ffc65a' : '#f1f6ff';
    value(ctx, `${sim.g.toFixed(1)}`, c3, py + 58, 28, gc);
    ctx.font = `700 11px ${SANS}`;
    ctx.fillStyle = 'rgba(160,185,215,0.9)';
    ctx.fillText('G', c3 + 54, py + 58);
    // AoA gauge
    label(ctx, 'AoA', c3, py + 82);
    const gx = c3;
    const gy = py + 90;
    const gw = 70;
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    rr(ctx, gx, gy, gw, 8, 4);
    ctx.fill();
    const stallPos = 0.82;
    ctx.fillStyle = 'rgba(80,220,130,0.55)';
    ctx.fillRect(gx + gw * 0.38 * stallPos, gy, gw * 0.24 * stallPos, 8);
    ctx.fillStyle = 'rgba(255,200,60,0.45)';
    ctx.fillRect(gx + gw * 0.62 * stallPos, gy, gw * 0.2 * stallPos, 8);
    ctx.fillStyle = 'rgba(255,70,60,0.55)';
    ctx.fillRect(gx + gw * stallPos, gy, gw * (1 - stallPos), 8);
    const aPos = clamp((sim.aoa / s.alphaStall) * stallPos, 0, 1);
    ctx.fillStyle = '#fff';
    ctx.fillRect(gx + gw * aPos - 1.5, gy - 3, 3, 14);
    ctx.font = `600 10px ${MONO}`;
    ctx.fillStyle = 'rgba(160,185,215,0.9)';
    ctx.fillText(`${((sim.aoa * 180) / Math.PI).toFixed(1)}°`, gx, gy + 24);
  }

  // ---------------- engine panel
  {
    const w = 244;
    const x = W - w - 14;
    const y = H - 146;
    panel(ctx, x, y, w, 132);
    // throttle bar
    const bx = x + 18;
    const by = y + 16;
    const bh = 98;
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    rr(ctx, bx, by, 20, bh, 6);
    ctx.fill();
    const tf = sim.throttle;
    const th = bh * tf;
    const g = ctx.createLinearGradient(0, by + bh, 0, by);
    g.addColorStop(0, '#2ec9ff');
    g.addColorStop(0.85, '#7dffa6');
    g.addColorStop(1, '#ff9a2e');
    ctx.fillStyle = g;
    rr(ctx, bx, by + bh - th, 20, Math.max(2, th), 6);
    ctx.fill();
    if (s.kind === 'jet') {
      ctx.strokeStyle = 'rgba(255,150,40,0.9)';
      ctx.setLineDash([3, 2]);
      ctx.beginPath();
      ctx.moveTo(bx - 3, by + bh * 0.15);
      ctx.lineTo(bx + 23, by + bh * 0.15);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.fillStyle = '#fff';
    ctx.fillRect(bx - 4, by + bh - bh * sim.thrust - 1, 28, 2);
    label(ctx, 'THR', bx + 10, y + 126, 'center');
    // fuel
    const fx = x + 52;
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    rr(ctx, fx, by, 14, bh, 5);
    ctx.fill();
    const ff = sim.fuelFrac;
    ctx.fillStyle = ff < 0.15 ? '#ff5a4d' : ff < 0.3 ? '#ffc233' : '#5fd1ff';
    rr(ctx, fx, by + bh - bh * ff, 14, Math.max(2, bh * ff), 5);
    ctx.fill();
    label(ctx, 'FUEL', fx + 7, y + 126, 'center');
    // numbers
    const nx = x + 80;
    ctx.textAlign = 'left';
    ctx.font = `700 16px ${MONO}`;
    ctx.fillStyle = '#f1f6ff';
    const thrPct = Math.round(sim.throttle * 100);
    ctx.fillText(`${s.kind === 'jet' && sim.throttle > 0.85 ? 'AB ' : ''}${thrPct}%`, nx, y + 30);
    ctx.font = `600 11px ${MONO}`;
    ctx.fillStyle = 'rgba(160,185,215,0.9)';
    ctx.fillText(`${Math.round(sim.fuel)} kg`, nx, y + 46);
    // chips
    const cw = 74;
    const gearDown = sim.gear > 0.95;
    const gearMove = sim.gear > 0.05 && sim.gear < 0.95;
    chip(ctx, gearMove ? 'GEAR ···' : gearDown ? 'GEAR ▼' : 'GEAR ▲', nx, y + 56, cw, gearDown || gearMove, gearMove ? '#ffc233' : '#7dffa6');
    chip(ctx, `FLAPS ${['0', '½', 'F'][sim.flaps]}`, nx + cw + 6, y + 56, 76, sim.flaps > 0, '#8fd0ff');
    chip(ctx, 'HOOK', nx, y + 80, cw, sim.hook, '#ffd24a');
    chip(ctx, sim.parked || sim.input.brake || sim.airbrake > 0.5 ? 'BRAKE' : 'BRAKE', nx + cw + 6, y + 80, 76, sim.parked || sim.input.brake, '#ff7a6b');
    chip(ctx, 'ASSIST', nx, y + 104, cw, sim.assist, '#b69cff');
    chip(ctx, 'A/THR', nx + cw + 6, y + 104, 76, sim.autoThr, '#7dffa6');
  }

  // ---------------- landing aid
  if (sim.mode === 'carrier') ols(ctx, W, H, sim);

  // ---------------- footer hints
  ctx.textAlign = 'center';
  ctx.font = `500 11px ${SANS}`;
  ctx.fillStyle = 'rgba(255,255,255,0.55)';
  const hint =
    sim.mode === 'carrier'
      ? '↑↓ pitch · ←→ throttle · SPACE catapult · G gear · F flaps · H hook · B brake · T turn · Y assist · K auto-thrust · R reset · ESC menu'
      : '↑↓ pitch · ←→ throttle · G gear · F flaps · B brake · T turn · Y assist · K auto-thrust · R respawn · ESC menu';
  if (W > 900) ctx.fillText(hint, W / 2, H - 6);

  // ---------------- crash overlay
  if (!sim.alive) {
    ctx.fillStyle = 'rgba(30,0,0,0.35)';
    ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center';
    ctx.font = `900 64px ${SANS}`;
    ctx.fillStyle = '#ff4a3d';
    ctx.fillText('CRASHED', W / 2, H / 2 - 20);
    ctx.font = `600 20px ${SANS}`;
    ctx.fillStyle = '#ffe3df';
    ctx.fillText(sim.crashReason, W / 2, H / 2 + 14);
    ctx.font = `500 15px ${SANS}`;
    ctx.fillStyle = 'rgba(255,255,255,0.8)';
    ctx.fillText('Press R to respawn · ESC for menu', W / 2, H / 2 + 46);
  }

  if (extra.paused) {
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    ctx.fillRect(0, 0, W, H);
  }
}
